import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Home } from './components/Home/home';

function App() {
  return (
    <div className="App-header">
      <Home/>
    </div>
  );
}

export default App;

