import Logo from "../../assets/activity.png";
import Bitcoin from "../../assets/bitcoin.png";
import { Asset } from "../Assets/asset";
export const Home = () => {

    let data = [
        {
            title:"Bitcoin[BTC]",
            price:"$31,812",
            change:"+10%",
            tvl:"$60,000",
        },
        {
            title:"Bitcoin[BTC]",
            price:"$31,812",
            change:"+10%",
            tvl:"$60,000",
        },
        {
            title:"Bitcoin[BTC]",
            price:"$31,812",
            change:"+10%",
            tvl:"$60,000",
        },
        {
            title:"Bitcoin[BTC]",
            price:"$31,812",
            change:"+10%",
            tvl:"$60,000",
        },
        {
            title:"Bitcoin[BTC]",
            price:"$31,812",
            change:"+10%",
            tvl:"$60,000",
        }
    ]
    
    return(
        <div>
            <div style={{display:"flex",marginTop:100,marginLeft:80}}>
                <img style={{width:16,height:16,marginTop:10,marginRight:5}} src={Logo} className="App-logo" alt="logo" />
                <div>Trending Assets</div>
            </div>
            <div style={{display:"flex",justifyContent:"space-between",marginLeft:20,marginRight:20}}>
                {data.map((item,index)=>{
                    return <Asset {...item}/>
                })}
            </div>
        </div>
    );
}