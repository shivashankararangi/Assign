import Background from "../../assets/vector.png";
import Field from "../../assets/field.png";
import Bitcoin from "../../assets/bitcoin.png";
import Circle from "../../assets/circle.png";
import Small from "../../assets/small.png";
import Solana from "../../assets/solana.png";
import { useState } from "react";

type PrivateProps = {
    title:String,
    price:String,
    change:String,
    tvl:String,
  }

export const Asset = (props: PrivateProps) => {
    // const [color,setColor] = useState("#FF4D4D");
    // if(props.change[0] === "+")
    // {
    //     setColor("#00FFA3");
    // }
    return(
        <div>
            <div style={{
                    position:"relative",
                    backgroundImage: `url(${Circle})`,
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "cover",
                    width:100,
                    height:100,
                    left: 95,
                    top: 55
                }}>
            <img style={{width:50,height:50,position: "relative",left: 25,top: 25}} src={Bitcoin} className="App-logo" alt="logo" />
            </div>
            <div style={{
                    backgroundImage: `url(${Background})`,
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "cover",
                    width:290,
                    height:350
                }}>
                <div style={{position:"relative",textAlign: "center",top: 75}}>
                    <div style={{color:"#737BAE",fontSize:12,position:"relative"}}>{props.title}</div>
                    <div style={{
                        backgroundImage: `url(${Field})`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: "cover",
                        width:240,
                        height:40,
                        top: 10,
                        left: 22,
                        position: "relative"
                        }}>
                        <div style={{color:"#ECF0FF",fontSize:16,position:"relative",top:7}}>
                            {props.price}
                            <span style={{marginLeft:5,color: props.change[0]==="-" ? "#FF4D4D":"#00FFA3",fontSize:12}}>{props.change}</span>
                        </div>
                    </div>
                    <div style={{color:"#737BAE",fontSize:12,marginTop:12}}>Price</div>
                    <div style={{
                        backgroundImage: `url(${Field})`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: "cover",
                        width:240,
                        height:40,
                        top: 10,
                        left: 22,
                        position: "relative"
                        }}>
                        <div style={{color:"#ECF0FF",fontSize:16,position:"relative",top:7}}>
                            {props.tvl}
                        </div>
                    </div>
                    <div style={{color:"#737BAE",fontSize:12,marginTop:12}}>TVL</div>
                    <div style={{
                        backgroundImage: `url(${Small})`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: "cover",
                        width:120,
                        height:40,
                        top: 10,
                        left: 85,
                        position: "relative"
                        }}>
                        <div style={{position:"relative",top:7,display:"flex",justifyContent:"space-between",marginLeft:20,marginRight:20}}>
                            <img src={Solana} width={22} height={22}/>
                            <img src={Solana} width={22} height={22}/>
                            <img src={Solana} width={22} height={22}/>
                        </div>
                    </div>
                    <div style={{color:"#737BAE",fontSize:12,marginTop:12}}>Popular Pairs</div>
                </div>
            </div>
        </div>
    );
}